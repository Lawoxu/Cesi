export const environment = {
  production: true,
  api_url: 'https://api.realworld.io/api'
};
